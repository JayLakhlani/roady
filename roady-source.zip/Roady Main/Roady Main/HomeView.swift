//
//  HomeView.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 07/10/2021.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack {
            NavigationView {
                ScrollView {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 18 ) {
                            ForEach(0 ..< 4) { item in
                                NavigationLink(destination: DetailView()) {
                                    CardView()
                                }
                            }
                        }
                        .padding(20)
                    }
                    .navigationTitle("Home")
                    
                    Text("What is Road Safety?")
                        .fontWeight(.bold)
                        .foregroundColor(.purple)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .font(.title)
                        
                    
                    Text("Road traffic safety refers to the methods and measures used to prevent road users from being killed or seriously injured. Typical road users include pedestrians, cyclists, motorists, vehicle passengers, horse riders, and passengers of on-road public transport (mainly buses 🚌 and trams 🚊).It is important to follow road rules to ensure safety of people and mostly small kids. It is very important to make kids understand about road safety and it's various protocols.  ")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding()
                    
                }
            }
        }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
