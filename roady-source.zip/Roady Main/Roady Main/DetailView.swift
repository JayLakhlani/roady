//
//  DetailView.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 07/10/2021.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        ScrollView {
            VStack (alignment: .leading, spacing: 11.0) {
                Image("Question Mark").resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 128)
                    .frame(maxWidth: .infinity)
                Text("Did You Know?")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Road Safety Facts")
             
            }
            .foregroundColor(.white)
            .padding(.all)
            .background(LinearGradient(
                gradient: Gradient(stops: [
                    .init(color: Color(#colorLiteral(red: 0.06493055820465088, green: 0.9166666865348816, blue: 0.6100415587425232, alpha: 1)), location: 0),
                    .init(color: Color(#colorLiteral(red: 0.08611112833023071, green: 0.4576666057109833, blue: 0.6666666865348816, alpha: 0.5899999737739563)), location: 0.9998999834060669),
                    .init(color: Color(#colorLiteral(red: 0.9624999761581421, green: 0.5373958349227905, blue: 0.5373958349227905, alpha: 0)), location: 1)]),
                startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
                endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727)))
        
            
            Text("About 1.3 million people die on the world's roads and 20 - 50 million are injured every year. Road traffic crashes are a major cause of death among all age groups and the leading cause of death for children and young adults aged 5–29 years.")
                .font(.title)
                .fontWeight(.bold)
                .padding()
        }
       
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
