//
//  CardView.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 07/10/2021.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        VStack (alignment: .leading, spacing: 11.0) {
            Image("Question Mark").resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 128)
                .frame(maxWidth: .infinity)
            Text("Did You Know?")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Road Safety Facts")
            Text("+Click to know ")
        }
        .foregroundColor(.white)
        .padding(.all)
        .frame(width: 252, height: 329)
        .background(LinearGradient(
            gradient: Gradient(stops: [
                .init(color: Color(#colorLiteral(red: 0.06493055820465088, green: 0.9166666865348816, blue: 0.6100415587425232, alpha: 1)), location: 0),
                .init(color: Color(#colorLiteral(red: 0.08611112833023071, green: 0.4576666057109833, blue: 0.6666666865348816, alpha: 0.5899999737739563)), location: 0.9998999834060669),
                .init(color: Color(#colorLiteral(red: 0.9624999761581421, green: 0.5373958349227905, blue: 0.5373958349227905, alpha: 0)), location: 1)]),
            startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
            endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727)))
        .cornerRadius(/*@START_MENU_TOKEN@*/30.0/*@END_MENU_TOKEN@*/)
    }
    
}


struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView()
    }
}
