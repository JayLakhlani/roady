//
//  Signs.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 08/10/2021.
//

import Foundation
import SwiftUI

struct Signs: Identifiable {
    let imageName: String
    let name: String
    let description: String
    let meaning: String
    let id = UUID()
}

let signs = [

    Signs(imageName: "Octogon Sign", name: "Red Octagon", description: "Tap to know more", meaning: "A road sign in the shape of an octagon will always be a stop sign. Come to a full stop at an intersection controlled by this sign. Stop at the marked stop line or before entering the crosswalk or before your vehicle enters the intersection. Let other vehicles or pedestrians pass if they are in your path."),
    Signs(imageName: "Yellow Triangle", name: "Yellow Triangle", description: "Tap to know more",  meaning: "This sign shape is used for yield signs. Yield the right of way. Slow down and let vehicles crossing your path go by. If necessary, stop before going ahead. If pedestrians are in or about to enter the crosswalk, stop until they have crossed the roadway, then proceed."),
    Signs(imageName: "Pennant", name: "Pennant", description: "Tap to know more", meaning: "This sign will be on the left-hand side of the road or highway. It warns you of a no-passing zone."),
    Signs(imageName: "Rectangle", name: "Yellow Rectangle", description: "Tap to know more", meaning: "These will be regulatory or guide signs. Vertical signs indicate what you should or should not do, such as speed limit signs. Horizontal signs give directions or information about services drivers may want."),
    Signs(imageName: "Diamond", name: "Yellow Diamond", description: "Tap to know more", meaning: "Diamond shaped signs are used as warning signs. These signs alert you to special road hazards. Words or pictures on the sign will show you why you need to slow down or use extra caution."),
    Signs(imageName: "Cross", name: "Cross", description: "Tap to know more", meaning: "All railroad crossing signs are this shape and are placed at each crossing. Sometimes there is a number under the crossbuck which will show you how many sets of tracks there are."),
    Signs(imageName: "SB", name: "Seat Belt", description: "Tap to know more", meaning: "Seat belts are the best defense against impaired, aggressive, and distracted drivers. Being buckled up during a crash helps keep you safe and secure inside your vehicle; being completely ejected from a vehicle is almost always deadly."),
    Signs(imageName: "HO", name: "Car Safety", description: "Tap to know more", meaning: "Do Not Take your Head or Hands out of Moving Vehicle: Because, then this can cause accidents and can hurt you badly. So make sure that you never ever do it and also ask your friends not to do it in future. Also make sure that you enter the bus and exit the bus only when it has stopped completely. Avoid playing in a moving bus as it can hurt you."),
]   
