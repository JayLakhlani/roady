//
//  Gradient Data.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 08/10/2021.
//

import SwiftUI

struct item: Identifiable {
let id = UUID()
    let gradient: LinearGradient
}

let items = [

    item(gradient: LinearGradient(
        gradient: Gradient(stops: [
    .init(color: Color(#colorLiteral(red: 0.06493055820465088, green: 0.9166666865348816, blue: 0.6100415587425232, alpha: 1)), location: 0),
    .init(color: Color(#colorLiteral(red: 0.08611112833023071, green: 0.4576666057109833, blue: 0.6666666865348816, alpha: 0.5899999737739563)), location: 0.9998999834060669),
    .init(color: Color(#colorLiteral(red: 0.9624999761581421, green: 0.5373958349227905, blue: 0.5373958349227905, alpha: 0)), location: 1)]),
        startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
        endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727)) ),
    
    item(gradient: LinearGradient(
        gradient: Gradient(stops: [
    .init(color: Color(#colorLiteral(red: 0.06493055820465088, green: 0.6100415587425232, blue: 0.9166666865348816, alpha: 1)), location: 0),
    .init(color: Color(#colorLiteral(red: 1, green: 0.3999999761581421, blue: 0.7600002288818359, alpha: 0.5099999904632568)), location: 0.9997999668121338),
    .init(color: Color(#colorLiteral(red: 0.08611112833023071, green: 0.4576666057109833, blue: 0.6666666865348816, alpha: 0.5899999737739563)), location: 0.9998999834060669)]),
        startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
        endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727))),
    
     item(gradient: LinearGradient(
    gradient: Gradient(stops: [
.init(color: Color(#colorLiteral(red: 0.9541666507720947, green: 0.15107643604278564, blue: 0.7293016314506531, alpha: 0.8299999833106995)), location: 0),
.init(color: Color(#colorLiteral(red: 0.08611112833023071, green: 0.4576666057109833, blue: 0.6666666865348816, alpha: 0.5899999737739563)), location: 0.9998999834060669),
.init(color: Color(#colorLiteral(red: 0.9624999761581421, green: 0.5373958349227905, blue: 0.5373958349227905, alpha: 0)), location: 1)]),
    startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
    endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727))),
    
    item(gradient: LinearGradient(
        gradient: Gradient(stops: [
    .init(color: Color(#colorLiteral(red: 0.9208333492279053, green: 0.05755209922790527, blue: 0.21294257044792175, alpha: 0.8299999833106995)), location: 0),
    .init(color: Color(#colorLiteral(red: 0.7454416751861572, green: 0.7583333253860474, blue: 0.11374998092651367, alpha: 1)), location: 0.9998999834060669),
    .init(color: Color(#colorLiteral(red: 0.9624999761581421, green: 0.5373958349227905, blue: 0.5373958349227905, alpha: 0)), location: 1)]),
        startPoint: UnitPoint(x: 1.1102230246251565e-16, y: 1.1102230246251565e-16),
        endPoint: UnitPoint(x: 1.0000000359665386, y: 0.896428578377727)))
]
