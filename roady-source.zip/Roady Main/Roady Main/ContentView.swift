//
//  ContentView.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 07/10/2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            RoadSigns()
                .tabItem {
                    Image(systemName: "hand.raised")
                    Text("Road Signs")
                }
            Rules().tabItem{
                Image(systemName: "doc.fill")
                Text("Rules")
            }
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

