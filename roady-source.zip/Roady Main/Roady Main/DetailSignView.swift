//
//  DetailSignView.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 08/10/2021.
//

import SwiftUI

struct DetailSignView: View {
    
    let signs: Signs
    
    var body: some View {
        VStack {
            Image(signs.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 200)
                .clipped()
            .shadow(color: .gray, radius: 5, x: 5, y: 7)
            Text(signs.name)
                .font(.title)
                .fontWeight(.bold)
            VStack{
                    Text("What does it mean?")
                        .foregroundColor(.red)
                        .font(.title)
                        .fontWeight(.bold)
                    Spacer()
                Text(signs.meaning)
                    .font(.title)
                        .foregroundColor(.blue)
                        .padding(16)
                .frame(width: .infinity, height: 500, alignment: .center)

            }
        }
    }
}

struct DetailSignView_Previews: PreviewProvider {
    static var previews: some View {
        DetailSignView(signs: signs[0])
    }
}
