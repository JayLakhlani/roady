//
//  Rules.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 08/10/2021.
//

import SwiftUI

struct Rules: View {
    var body: some View {
        VStack {
            NavigationView {
                List {
                    Text("Know signal meanings")
                        .padding()
                    Text("Stop, look, cross")
                        .padding()
                    Text("Pay attention — listen")
                        .padding()
                    Text("Don't rush when on a road")
                        .padding()
                    Text("Always use the sidewalk")
                        .padding()
                    Text("Stay safe inside a moving vehicle")
                        .padding()
                    Text("Ride bicycles carefully")
                        .padding()
                }
                .font(.title)
                .navigationTitle("Road Safety Rules")
                
            }
            Image("Cycle")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 175, height: 175)
        }
        
    }
}

struct Rules_Previews: PreviewProvider {
    static var previews: some View {
        Rules()
    }
}
