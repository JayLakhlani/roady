//
//  Roady_MainApp.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 07/10/2021.
//

import SwiftUI

@main
struct Roady_MainApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
