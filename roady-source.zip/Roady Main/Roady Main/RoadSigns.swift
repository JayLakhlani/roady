//
//  RoadSigns.swift
//  Roady Main
//
//  Created by Jay Lakhlani on 08/10/2021.
//

import SwiftUI

struct RoadSigns: View {
    var body: some View {
        NavigationView{
            List(signs){ signs in
                NavigationLink(destination: DetailSignView(signs: signs)) {
                    SignRow(signs: signs)
                }
                
            }
            .navigationBarTitle("Different Road Signs")
        }
       
        
    }
}

struct RoadSigns_Previews: PreviewProvider {
    static var previews: some View {
        RoadSigns()
    }
}

struct SignRow: View {
    
    let signs: Signs
    
    var body: some View {
        HStack{
            Image(signs.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 60, height: 60)
                .shadow(color: .gray, radius: 4, x: 3, y: 3)
                .clipped()
            VStack (alignment: .leading){
                Text(signs.name)
                    .font(.system(size: 21, weight: .bold, design: .default))
                Text(signs.description)
            }
            .padding()
        }
    }
}
